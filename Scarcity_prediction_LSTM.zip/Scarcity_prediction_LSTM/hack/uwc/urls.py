from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('map/', views.map, name="map"),
    path('turbidity/', views.turbidity, name="turbidity"),
    path('turgraph/', views.turgraph, name="turgraph"),
    path('flowrate/', views.flowrate, name="flowrate"),
    path('moisture/', views.moisture, name="moisture"),
    path('levelrange/', views.levelrange, name="levelrange"),
    path('sensortable/', views.sensortable, name="sensortable"),
    path('passage/', views.passage, name="passage"),
    path('map2/', views.map2, name="map2"),
    path('sensor_data/', views.sensor_data, name="sensor_data"),
    path('graphs/', views.graphs, name="graphs"),
]