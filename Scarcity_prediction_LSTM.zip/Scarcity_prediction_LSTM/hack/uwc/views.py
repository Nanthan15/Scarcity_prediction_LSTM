from django.shortcuts import render
from .models import Sensors
from django.http import HttpResponse
from django.shortcuts import render
import firebase_admin
from firebase_admin import db
from django.http import JsonResponse
import requests
import zipfile
import io
import base64

def f(request):
    return HttpResponse("But this works")
def Display(request,sensor1=None,sensor2=None,sensor3=None,sensor4=None,sensor5=None,sensor6=None,time=None):
    all_sensors=Sensors()
    all_sensors.sensor1=float(sensor1)
    all_sensors.sensor2=float(sensor2)
    all_sensors.sensor3=float(sensor3)
    all_sensors.sensor4=float(sensor4)
    all_sensors.sensor5=float(sensor5)
    all_sensors.sensor6=float(sensor6)
    all_sensors.time=str(time)
    all_sensors.save()
    p=Sensors.objects.all()[len(Sensors.objects.all())-10::][::-1]
    return render(request,'uwc/map.html',{'all_sensors':p})
def func(request):
    return render(request,'uwc/start.html')
def map(request):
    a=Sensors.objects.all()[len(Sensors.objects.all())-10::][::-1]
    return render(request ,'uwc/map.html',{'all_sensors':a})
def map2(request):
    a=Sensors.objects.all()[len(Sensors.objects.all())-10::][::-1]
    return render(request ,'uwc/map2.html',{'all_sensors':a})

def sensortable(request):
    ref = db.reference('/sensors')  # Reference to Firebase path
    data = ref.get()

    # Ensure data is in list format for Django template rendering
    all_sensors = []
    if isinstance(data, dict):
        for key, value in data.items():
            all_sensors.append(value)
    elif isinstance(data, list):
        all_sensors = data

    return render(request, 'uwc/sensortable.html', {'all_sensors': all_sensors})


def turbidity(request):
    a=Sensors.objects.all()[len(Sensors.objects.all())-1::]
    return render(request ,'uwc/turbiditycheck.html',{'all_sensors':a})
def home(request):
    a=Sensors.objects.all()[len(Sensors.objects.all())-1::]
    return render(request ,'uwc/hack-home.html',{'all_sensors':a})
def flowrate(request):
    a=Sensors.objects.all()[len(Sensors.objects.all())-10::][::-1]
    count=0
    for i in a:
        i.serialId=str(count)
        count+=1
    return render(request ,'uwc/flowrate.html',{'all_sensors':a})
def turgraph(request):
    a=Sensors.objects.all()[len(Sensors.objects.all())-10::][::-1]
    count=0
    for i in a:
        i.serialId=str(count)
        count+=1
    return render(request ,'uwc/turgraph.html',{'all_sensors':a})
def moisture(request):
    a=Sensors.objects.all()[len(Sensors.objects.all())-10::][::-1]
    count=0
    for i in a:
        i.serialId=str(count)
        count+=1
    return render(request ,'uwc/moisture.html',{'all_sensors':a})
def levelrange(request):
    a=Sensors.objects.all()[len(Sensors.objects.all())-10::][::-1]
    count=0
    for i in a:
        i.serialId=str(count)
        count+=1
    return render(request ,'uwc/levelrange.html',{'all_sensors':a})
def passage(request):
    a=Sensors.objects.all()[len(Sensors.objects.all())-10::][::-1]
    count=0
    for i in a:
        i.serialId=str(count)
        count+=1
    return render(request ,'uwc/passage.html',{'all_sensors':a})



def sensor_data(request):
    ref = db.reference('/sensors')  # Reference to Firebase path
    data = ref.get()

    # Ensure data is in list format for Django template rendering
    all_sensors = []
    if data:
        for key, value in data.items():
            all_sensors.append(value)

    return render(request, 'uwc/sensortable.html', {'all_sensors': all_sensors})

def graphs(request):
    if request.method == 'POST':
        state = request.POST.get('state')
        district = request.POST.get('district')
        try:
            response = requests.post('http://127.0.0.1:5000/get_graphs', json={'state': state, 'district': district})
            response.raise_for_status()
            
            # Handle the zip file response
            zip_file = zipfile.ZipFile(io.BytesIO(response.content))
            images = {}
            for file_name in zip_file.namelist():
                with zip_file.open(file_name) as img_file:
                    img_data = img_file.read()
                    img_base64 = base64.b64encode(img_data).decode('utf-8')
                    images[file_name] = img_base64
            
            return render(request, 'uwc/graphs.html', {'images': images})
        except requests.exceptions.RequestException as e:
            return render(request, 'uwc/graphs.html', {'error': str(e)})
    return render(request, 'uwc/graphs.html')